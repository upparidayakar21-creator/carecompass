/**
 * @fileoverview 3-Tier Backend REST API & Static File Server for CareCompass: BedFinder Blitz
 * Endpoints:
 *   GET   /api/health                 - Service health & uptime check
 *   GET   /api/hospitals              - Lists hospitals sorted by Haversine proximity (?lat=&lon=&specialty=&maxKm=)
 *   POST  /api/auth/admin             - Authenticates hospital staff and issues Bearer session token
 *   PATCH /api/hospitals/:id/beds     - Protected route updating live bed inventory in JSON store
 *   POST  /api/dispatch               - Logs Ambulance Pre-Arrival Dispatch Alerts
 *   GET   /api/dispatch               - Lists recent incoming ambulance alerts
 */

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

import { INITIAL_HOSPITALS } from './js/hospitals-data.js';
import { calculateHaversineKm, getEmergencyStatus } from './js/haversine.js';
import { validateBedCount, sanitizeSearchOrText } from './js/security.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'carecompass-db.json');

// Valid authorized staff credentials (in production, hashed in DB)
const VALID_STAFF = {
  'MED-ADMIN': { pin: '1080', name: 'Dr. R. Sharma (ER Chief)' },
  'ER-DESK': { pin: '2026', name: 'Nurse K. Rao (Triage Desk)' }
};

const activeTokens = new Map();

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    const initialDb = {
      hospitals: INITIAL_HOSPITALS,
      dispatches: []
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), 'utf-8');
  }
}

function readDb() {
  ensureDb();
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    if (!Array.isArray(parsed.hospitals) || !parsed.hospitals.length) {
      parsed.hospitals = INITIAL_HOSPITALS;
    }
    if (!Array.isArray(parsed.dispatches)) {
      parsed.dispatches = [];
    }
    return parsed;
  } catch {
    return { hospitals: INITIAL_HOSPITALS, dispatches: [] };
  }
}

function writeDb(db) {
  ensureDb();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
}

function sendJson(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN'
  });
  res.end(JSON.stringify(payload));
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1024 * 1024) {
        reject(new Error('Request payload exceeds 1 MB limit.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error('Malformed JSON request body.'));
      }
    });
    req.on('error', reject);
  });
}

function verifyBearerToken(req) {
  const authHeader = String(req.headers.authorization || '');
  if (!authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7).trim();
  return activeTokens.get(token) || null;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  // 1. Health Check
  if (pathname === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, {
      status: 'ok',
      service: 'CareCompass BedFinder API',
      timestamp: new Date().toISOString()
    });
  }

  // 2. Hospital Directory Query with Server-Side Haversine Proximity & Specialty Filtering
  if (pathname === '/api/hospitals' && req.method === 'GET') {
    const db = readDb();
    const latParam = url.searchParams.get('lat');
    const lonParam = url.searchParams.get('lon');
    const specialtyParam = url.searchParams.get('specialty');
    const maxKmParam = Number(url.searchParams.get('maxKm'));

    const hasCoords = latParam !== null && lonParam !== null &&
      Number.isFinite(Number(latParam)) && Number.isFinite(Number(lonParam));

    let results = db.hospitals.map(h => {
      const distanceKm = hasCoords
        ? calculateHaversineKm(Number(latParam), Number(lonParam), h.lat, h.lon)
        : null;
      return {
        ...h,
        distanceKm,
        status: getEmergencyStatus(h.beds)
      };
    });

    if (specialtyParam) {
      const cleanSpec = sanitizeSearchOrText(specialtyParam, { maxLen: 60 }).value.toLowerCase();
      if (cleanSpec) {
        results = results.filter(h =>
          h.specialties.some(s => s.toLowerCase().includes(cleanSpec))
        );
      }
    }

    if (hasCoords) {
      results.sort((a, b) => a.distanceKm - b.distanceKm);
      if (Number.isFinite(maxKmParam) && maxKmParam > 0) {
        results = results.filter(h => h.distanceKm <= maxKmParam);
      }
    }

    return sendJson(res, 200, { count: results.length, hospitals: results });
  }

  // 3. Protected Hospital Admin Authentication
  if (pathname === '/api/auth/admin' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      const staffId = String(body.staffId || '').trim().toUpperCase();
      const pin = String(body.pin || '').trim();
      const staffRecord = VALID_STAFF[staffId];

      if (!staffRecord || staffRecord.pin !== pin) {
        return sendJson(res, 401, { error: 'Unauthorized: Invalid Staff ID or Emergency PIN.' });
      }

      const token = crypto.randomBytes(20).toString('hex');
      const session = {
        staffId,
        name: staffRecord.name,
        hospitalId: String(body.hospitalId || 'all'),
        issuedAt: new Date().toISOString()
      };
      activeTokens.set(token, session);

      return sendJson(res, 200, { token, staff: session });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  // 4. Protected Live Bed Inventory Update
  const bedMatch = pathname.match(/^\/api\/hospitals\/([a-zA-Z0-9-]+)\/beds$/);
  if (bedMatch && req.method === 'PATCH') {
    const admin = verifyBearerToken(req);
    if (!admin) {
      return sendJson(res, 401, { error: 'Unauthorized: Valid hospital staff token required.' });
    }

    try {
      const hospitalId = bedMatch[1];
      const body = await parseBody(req);
      const incomingBeds = body.beds || {};

      const gen = validateBedCount(incomingBeds.general);
      const icu = validateBedCount(incomingBeds.icu);
      const vent = validateBedCount(incomingBeds.ventilator);
      const oxy = validateBedCount(incomingBeds.oxygen);

      if (!gen.valid || !icu.valid || !vent.valid || !oxy.valid) {
        return sendJson(res, 400, { error: 'All bed counts must be integers between 0 and 500.' });
      }

      const db = readDb();
      const idx = db.hospitals.findIndex(h => h.id === hospitalId);
      if (idx === -1) {
        return sendJson(res, 404, { error: 'Hospital not found.' });
      }

      db.hospitals[idx].beds = {
        general: gen.value,
        icu: icu.value,
        ventilator: vent.value,
        oxygen: oxy.value
      };
      db.hospitals[idx].updatedAt = new Date().toISOString();
      db.hospitals[idx].updatedBy = admin.staffId;
      writeDb(db);

      return sendJson(res, 200, {
        updated: true,
        hospital: db.hospitals[idx],
        status: getEmergencyStatus(db.hospitals[idx].beds)
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  // 5. Ambulance Pre-Arrival Dispatch Alerts
  if (pathname === '/api/dispatch' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      const hospCheck = sanitizeSearchOrText(body.hospitalName, { minLen: 2, maxLen: 100, field: 'Hospital name' });
      const typeCheck = sanitizeSearchOrText(body.emergencyType, { minLen: 2, maxLen: 60, field: 'Emergency type' });
      const notesCheck = sanitizeSearchOrText(body.notes || '', { maxLen: 240, field: 'Notes' });

      if (!hospCheck.valid || !typeCheck.valid) {
        return sendJson(res, 400, { error: 'Hospital name and emergency type are required.' });
      }

      const db = readDb();
      const dispatch = {
        id: `DSP-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        hospitalId: String(body.hospitalId || ''),
        hospitalName: hospCheck.value,
        emergencyType: typeCheck.value,
        etaMinutes: Math.max(1, Number(body.etaMinutes) || 8),
        notes: notesCheck.value,
        createdAt: new Date().toISOString(),
        status: 'ER Desk Notified'
      };
      db.dispatches.unshift(dispatch);
      db.dispatches = db.dispatches.slice(0, 50);
      writeDb(db);

      return sendJson(res, 201, { created: true, dispatch });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  if (pathname === '/api/dispatch' && req.method === 'GET') {
    const db = readDb();
    return sendJson(res, 200, { dispatches: db.dispatches });
  }

  // 6. Static Asset Serving with Path Traversal Prevention
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const resolvedPath = path.resolve(__dirname, '.' + safePath);
  if (!resolvedPath.startsWith(__dirname)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.stat(resolvedPath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Not found');
    }
    const ext = path.extname(resolvedPath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    fs.createReadStream(resolvedPath).pipe(res);
  });
});

if (process.argv[1] === __filename) {
  server.listen(PORT, () => {
    console.log(`CareCompass BedFinder server running at http://localhost:${PORT}`);
  });
}

export { server, activeTokens };
