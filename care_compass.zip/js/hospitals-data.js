/**
 * @fileoverview Comprehensive 15-Hospital Urban District Dataset with Coordinates,
 * Specialties, Emergency Contacts, and Live Bed Inventories.
 */

const minsAgoIso = m => new Date(Date.now() - m * 60000).toISOString();

export const CITY_PRESETS = [
  { id: 'central', name: 'Central Medical District (Default)', lat: 17.4399, lon: 78.4983 },
  { id: 'north', name: 'North Industrial Corridor (Jeedimetla)', lat: 17.5150, lon: 78.4420 },
  { id: 'west', name: 'West IT Hub (Hitech City)', lat: 17.4435, lon: 78.3772 },
  { id: 'south', name: 'South Highway Junction', lat: 17.3616, lon: 78.4747 }
];

export const ALL_SPECIALTIES = [
  '24/7 Trauma Center',
  'Cath Lab',
  'Pediatric ICU',
  'Burn Unit',
  'Cardiology',
  'Neurology',
  '24/7 Pharmacy'
];

export const INITIAL_HOSPITALS = [
  {
    id: 'hosp-01',
    name: 'City Care Multi-Specialty Hospital',
    district: 'Secunderabad Central',
    address: '14-2-108 Station Road, Secunderabad',
    phone: '+91-40-2770-1108',
    lat: 17.4485,
    lon: 78.5012,
    beds: { general: 42, icu: 4, ventilator: 3, oxygen: 18 },
    specialties: ['24/7 Trauma Center', 'Cath Lab', 'Cardiology', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(6)
  },
  {
    id: 'hosp-02',
    name: 'Apex Heart & Trauma Institute',
    district: 'Begumpet',
    address: '6-3-882 Greenlands Avenue, Begumpet',
    phone: '+91-40-2341-9911',
    lat: 17.4442,
    lon: 78.4675,
    beds: { general: 58, icu: 7, ventilator: 5, oxygen: 24 },
    specialties: ['24/7 Trauma Center', 'Cath Lab', 'Cardiology', 'Neurology', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(12)
  },
  {
    id: 'hosp-03',
    name: 'LifeLine Emergency & Burn Center',
    district: 'Ameerpet',
    address: '8-3-214 Maitrivanam Enclave, Ameerpet',
    phone: '+91-40-2374-4400',
    lat: 17.4375,
    lon: 78.4482,
    beds: { general: 30, icu: 2, ventilator: 1, oxygen: 11 },
    specialties: ['24/7 Trauma Center', 'Burn Unit', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(18)
  },
  {
    id: 'hosp-04',
    name: 'Rainbow Pediatric & Neonatal Care',
    district: 'Banjara Hills',
    address: 'Road No. 10, Banjara Hills',
    phone: '+91-40-2335-7700',
    lat: 17.4156,
    lon: 78.4347,
    beds: { general: 36, icu: 6, ventilator: 4, oxygen: 15 },
    specialties: ['Pediatric ICU', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(9)
  },
  {
    id: 'hosp-05',
    name: 'Metro General & Critical Care',
    district: 'Kukatpally',
    address: 'Plot 45, KPHB Phase III, Kukatpally',
    phone: '+91-40-2305-8822',
    lat: 17.4948,
    lon: 78.3996,
    beds: { general: 74, icu: 0, ventilator: 0, oxygen: 9 },
    specialties: ['24/7 Trauma Center', 'Neurology', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(4)
  },
  {
    id: 'hosp-06',
    name: 'Deccan Neuro & Stroke Center',
    district: 'Somajiguda',
    address: '6-3-652 Raj Bhavan Road, Somajiguda',
    phone: '+91-40-2331-5500',
    lat: 17.4258,
    lon: 78.4570,
    beds: { general: 28, icu: 5, ventilator: 4, oxygen: 14 },
    specialties: ['Neurology', 'Cath Lab', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(22)
  },
  {
    id: 'hosp-07',
    name: 'Suraram Industrial Trauma Hospital',
    district: 'Jeedimetla / Suraram',
    address: 'NH-44 Industrial Estate Road, Suraram',
    phone: '+91-40-2309-6611',
    lat: 17.5221,
    lon: 78.4368,
    beds: { general: 48, icu: 8, ventilator: 5, oxygen: 22 },
    specialties: ['24/7 Trauma Center', 'Burn Unit', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(11)
  },
  {
    id: 'hosp-08',
    name: 'Cyberabad Medicity Hospital',
    district: 'Madhapur',
    address: 'Plot 19, Hi-Tech City Main Rd, Madhapur',
    phone: '+91-40-2311-3344',
    lat: 17.4483,
    lon: 78.3915,
    beds: { general: 85, icu: 11, ventilator: 7, oxygen: 29 },
    specialties: ['24/7 Trauma Center', 'Cath Lab', 'Cardiology', 'Pediatric ICU', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(15)
  },
  {
    id: 'hosp-09',
    name: 'Apollo Reach Jubilee Clinic',
    district: 'Jubilee Hills',
    address: 'Road No. 36, Jubilee Hills',
    phone: '+91-40-2360-7777',
    lat: 17.4311,
    lon: 78.4112,
    beds: { general: 62, icu: 9, ventilator: 6, oxygen: 21 },
    specialties: ['Cath Lab', 'Cardiology', 'Neurology', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(27)
  },
  {
    id: 'hosp-10',
    name: 'Sunrise Women & Children Hospital',
    district: 'Kondapur',
    address: 'Botanical Garden Rd, Kondapur',
    phone: '+91-40-2300-4455',
    lat: 17.4622,
    lon: 78.3568,
    beds: { general: 40, icu: 4, ventilator: 2, oxygen: 16 },
    specialties: ['Pediatric ICU', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(14)
  },
  {
    id: 'hosp-11',
    name: 'Charminar Government District Hospital',
    district: 'Old City / Charminar',
    address: '22-4-112 Patel Market Road, Charminar',
    phone: '+91-40-2452-1080',
    lat: 17.3614,
    lon: 78.4745,
    beds: { general: 96, icu: 3, ventilator: 2, oxygen: 25 },
    specialties: ['24/7 Trauma Center', 'Burn Unit', 'Pediatric ICU', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(35)
  },
  {
    id: 'hosp-12',
    name: 'Uppal East Horizon Medical Center',
    district: 'Uppal',
    address: 'Survey 88, Warangal Highway, Uppal',
    phone: '+91-40-2720-9090',
    lat: 17.4058,
    lon: 78.5591,
    beds: { general: 52, icu: 5, ventilator: 3, oxygen: 19 },
    specialties: ['24/7 Trauma Center', 'Cardiology', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(41)
  },
  {
    id: 'hosp-13',
    name: 'Gachibowli Continental Critical Care',
    district: 'Gachibowli',
    address: 'Financial District Loop, Gachibowli',
    phone: '+91-40-6700-0108',
    lat: 17.4239,
    lon: 78.3428,
    beds: { general: 90, icu: 14, ventilator: 9, oxygen: 30 },
    specialties: ['24/7 Trauma Center', 'Cath Lab', 'Cardiology', 'Neurology', 'Burn Unit', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(8)
  },
  {
    id: 'hosp-14',
    name: 'Malkajgiri Community Health Wing',
    district: 'Malkajgiri',
    address: '12-1-45 Anandbagh Cross Roads, Malkajgiri',
    phone: '+91-40-2705-1122',
    lat: 17.4472,
    lon: 78.5320,
    beds: { general: 24, icu: 1, ventilator: 1, oxygen: 7 },
    specialties: ['24/7 Pharmacy'],
    updatedAt: minsAgoIso(265) // > 4 hours old to demonstrate stale-data warning badge
  },
  {
    id: 'hosp-15',
    name: 'LB Nagar South Trauma & Ortho Center',
    district: 'LB Nagar',
    address: 'NH-65 Vijayawada Highway, LB Nagar',
    phone: '+91-40-2403-8899',
    lat: 17.3457,
    lon: 78.5522,
    beds: { general: 66, icu: 6, ventilator: 4, oxygen: 20 },
    specialties: ['24/7 Trauma Center', 'Cardiology', '24/7 Pharmacy'],
    updatedAt: minsAgoIso(19)
  }
];
