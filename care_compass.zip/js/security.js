/**
 * @fileoverview Security, XSS Sanitization, and Input Validation Module for CareCompass
 */

/**
 * Escapes HTML special characters to prevent Cross-Site Scripting (XSS) in search, notes, and hospital names.
 * @param {unknown} raw
 * @returns {string}
 */
export function sanitizeHTML(raw) {
  return String(raw ?? '').replace(/[&<>"'`]/g, ch => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '`': '&#96;'
  })[ch]);
}

/**
 * Sanitizes and validates free-text inputs (search queries, dispatch notes, hospital search).
 * Strips control characters and dangerous HTML angle brackets.
 * @param {unknown} input
 * @param {{ maxLen?: number, minLen?: number, field?: string }} [opts]
 * @returns {{ valid: boolean, value: string, error?: string }}
 */
export function sanitizeSearchOrText(input, { maxLen = 120, minLen = 0, field = 'Input' } = {}) {
  if (typeof input !== 'string') {
    return { valid: false, value: '', error: `${field} must be text.` };
  }
  const cleaned = input
    .replace(/[\x00-\x1F\x7F]/g, '')
    .replace(/[<>]/g, '')
    .trim();

  if (cleaned.length < minLen) {
    return { valid: false, value: cleaned, error: `${field} must be at least ${minLen} characters.` };
  }
  if (cleaned.length > maxLen) {
    return { valid: false, value: cleaned.slice(0, maxLen), error: `${field} cannot exceed ${maxLen} characters.` };
  }
  return { valid: true, value: cleaned };
}

/**
 * Validates non-negative integer bed counts within safe hospital bounds (0..500).
 * @param {unknown} value
 * @returns {{ valid: boolean, value: number, error?: string }}
 */
export function validateBedCount(value) {
  const num = Number(value);
  if (!Number.isInteger(num) || num < 0 || num > 500) {
    return { valid: false, value: 0, error: 'Bed count must be an integer between 0 and 500.' };
  }
  return { valid: true, value: num };
}
