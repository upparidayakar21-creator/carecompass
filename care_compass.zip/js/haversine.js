/**
 * @fileoverview Pure Geodesic Proximity & Emergency Triage Engine for CareCompass
 * Implements the Haversine distance formula, Golden Hour traffic-adjusted transit estimation,
 * bed status classification, and staleness detection.
 */

const EARTH_RADIUS_KM = 6371;

/**
 * Converts degrees to radians.
 * @param {number} deg
 * @returns {number}
 */
export function toRadians(deg) {
  return (Number(deg) * Math.PI) / 180;
}

/**
 * Calculates straight-line geodesic distance in kilometers between two GPS coordinates
 * using the Haversine formula.
 * @param {number} lat1
 * @param {number} lon1
 * @param {number} lat2
 * @param {number} lon2
 * @returns {number} Distance in km rounded to 2 decimal places
 */
export function calculateHaversineKm(lat1, lon1, lat2, lon2) {
  const coords = [lat1, lon1, lat2, lon2].map(Number);
  if (coords.some(v => !Number.isFinite(v))) {
    throw new TypeError('All latitude and longitude coordinates must be finite numbers.');
  }

  const [la1, lo1, la2, lo2] = coords;
  const dLat = toRadians(la2 - la1);
  const dLon = toRadians(lo2 - lo1);
  const rLat1 = toRadians(la1);
  const rLat2 = toRadians(la2);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(rLat1) * Math.cos(rLat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Number((EARTH_RADIUS_KM * c).toFixed(2));
}

/**
 * Estimates Golden Hour driving transit time in minutes based on distance and simulated traffic congestion.
 * @param {number} distanceKm
 * @param {'low'|'moderate'|'heavy'} [trafficLevel='moderate']
 * @returns {{ minutes: number, goldenHourRisk: 'Optimal'|'Caution'|'Critical' }}
 */
export function estimateGoldenHourTransit(distanceKm, trafficLevel = 'moderate') {
  const dist = Math.max(0, Number(distanceKm) || 0);
  const speedMap = { low: 45, moderate: 30, heavy: 18 };
  const avgSpeedKmh = speedMap[trafficLevel] || 30;
  const minutes = Math.max(2, Math.round((dist / avgSpeedKmh) * 60 + 2));

  let goldenHourRisk = 'Optimal';
  if (minutes > 35) goldenHourRisk = 'Critical';
  else if (minutes > 18) goldenHourRisk = 'Caution';

  return { minutes, goldenHourRisk };
}

/**
 * Determines visual emergency status badge from ICU, Ventilator, Oxygen, and General bed inventory.
 * @param {{ general: number, icu: number, ventilator: number, oxygen: number }} beds
 * @returns {{ code: 'normal'|'busy'|'divert', label: string }}
 */
export function getEmergencyStatus(beds) {
  const icu = Number(beds?.icu || 0);
  const vent = Number(beds?.ventilator || 0);
  const oxy = Number(beds?.oxygen || 0);
  const gen = Number(beds?.general || 0);

  if (icu === 0 && vent === 0 && gen === 0) {
    return { code: 'divert', label: 'ER Full - Divert' };
  }
  if (icu === 0) {
    return { code: 'divert', label: 'ICU Full - Divert' };
  }
  if (icu <= 2 || vent <= 1 || oxy <= 3) {
    return { code: 'busy', label: 'Busy · Low ICU' };
  }
  return { code: 'normal', label: 'Normal · Beds Available' };
}

/**
 * Formats relative update age and flags records older than 4 hours (240 mins) as stale.
 * @param {string|number} updatedAtIso
 * @param {number} [nowMs=Date.now()]
 * @returns {{ text: string, isStale: boolean, minutesAgo: number }}
 */
export function getFreshnessInfo(updatedAtIso, nowMs = Date.now()) {
  const ts = Date.parse(String(updatedAtIso || ''));
  if (!Number.isFinite(ts)) {
    return { text: 'Updated recently', isStale: false, minutesAgo: 0 };
  }
  const minutesAgo = Math.max(0, Math.floor((nowMs - ts) / 60000));
  const isStale = minutesAgo >= 240;

  if (minutesAgo < 1) return { text: 'Updated just now', isStale: false, minutesAgo };
  if (minutesAgo < 60) return { text: `Last Updated: ${minutesAgo} min${minutesAgo === 1 ? '' : 's'} ago`, isStale, minutesAgo };
  const hours = Math.floor(minutesAgo / 60);
  return {
    text: isStale ? `⚠ Stale Data (${hours}h ago — Verify by phone)` : `Last Updated: ${hours}h ago`,
    isStale,
    minutesAgo
  };
}
