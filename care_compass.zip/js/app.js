/**
 * @fileoverview Main Application Controller for CareCompass: BedFinder Blitz v2.0
 * Coordinates Haversine proximity ranking, specialty & bed filters, paginated directory,
 * interactive Leaflet map, protected Hospital Admin Console, and Ambulance Pre-Arrival Dispatch.
 */

import {
  calculateHaversineKm,
  estimateGoldenHourTransit,
  getEmergencyStatus,
  getFreshnessInfo
} from './haversine.js';

import {
  sanitizeHTML,
  sanitizeSearchOrText,
  validateBedCount
} from './security.js';

import {
  CITY_PRESETS,
  ALL_SPECIALTIES,
  INITIAL_HOSPITALS
} from './hospitals-data.js';

import {
  readCachedHospitals,
  writeCachedHospitals,
  fetchHospitalsFromApi,
  loginHospitalAdmin,
  getActiveAdminSession,
  logoutHospitalAdmin,
  updateHospitalBedsProtected,
  sendPreArrivalDispatch,
  DISPATCH_LOG_KEY
} from './storage.js';

const PAGE_SIZE = 6;

const state = {
  hospitals: readCachedHospitals() || structuredClone(INITIAL_HOSPITALS),
  userLat: CITY_PRESETS[0].lat,
  userLon: CITY_PRESETS[0].lon,
  locationName: CITY_PRESETS[0].name,
  searchQuery: '',
  bedRequirement: 'any',
  maxKm: 0,
  trafficLevel: 'moderate',
  selectedSpecialties: new Set(),
  currentPage: 1,
  activeTab: 'directory',
  adminSession: getActiveAdminSession(),
  dispatches: []
};

try {
  state.dispatches = JSON.parse(localStorage.getItem(DISPATCH_LOG_KEY) || '[]');
} catch {
  state.dispatches = [];
}

let leafletMap = null;
let markerLayer = null;
let toastTimer = null;

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

function notify(msg) {
  const el = $('#toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}

function getFilteredAndRankedHospitals() {
  const cleanSearch = sanitizeSearchOrText(state.searchQuery, { maxLen: 100 }).value.toLowerCase();

  return state.hospitals
    .map(hospital => {
      const distanceKm = calculateHaversineKm(state.userLat, state.userLon, hospital.lat, hospital.lon);
      const transit = estimateGoldenHourTransit(distanceKm, state.trafficLevel);
      const status = getEmergencyStatus(hospital.beds);
      const freshness = getFreshnessInfo(hospital.updatedAt);
      return {
        ...hospital,
        distanceKm,
        transit,
        status,
        freshness
      };
    })
    .filter(h => {
      if (state.maxKm > 0 && h.distanceKm > state.maxKm) return false;

      if (state.bedRequirement === 'icu' && h.beds.icu <= 0) return false;
      if (state.bedRequirement === 'ventilator' && (h.beds.icu <= 0 || h.beds.ventilator <= 0)) return false;
      if (state.bedRequirement === 'oxygen' && h.beds.oxygen <= 0) return false;
      if (state.bedRequirement === 'general' && h.beds.general <= 0) return false;

      if (state.selectedSpecialties.size > 0) {
        for (const reqSpec of state.selectedSpecialties) {
          if (!h.specialties.includes(reqSpec)) return false;
        }
      }

      if (cleanSearch) {
        const hay = `${h.name} ${h.district} ${h.address} ${h.specialties.join(' ')}`.toLowerCase();
        if (!hay.includes(cleanSearch)) return false;
      }

      return true;
    })
    .sort((a, b) => a.distanceKm - b.distanceKm);
}

function renderKpiStrip(ranked) {
  const totalIcu = ranked.reduce((s, h) => s + h.beds.icu, 0);
  const totalVent = ranked.reduce((s, h) => s + h.beds.ventilator, 0);
  const totalOxy = ranked.reduce((s, h) => s + h.beds.oxygen, 0);
  const openCount = ranked.filter(h => h.status.code !== 'divert').length;

  $('#kpiStrip').innerHTML = `
    <div class="kpi-card">
      <span>Matching Hospitals</span>
      <strong>${openCount} <small style="font-size:14px;color:var(--muted)">/ ${ranked.length} accepting</small></strong>
    </div>
    <div class="kpi-card">
      <span>Live ICU Beds</span>
      <strong style="color:var(--green)">${totalIcu}</strong>
    </div>
    <div class="kpi-card">
      <span>Ventilator Beds</span>
      <strong style="color:var(--primary)">${totalVent}</strong>
    </div>
    <div class="kpi-card">
      <span>Oxygen-Supported Beds</span>
      <strong>${totalOxy}</strong>
    </div>
  `;
}

function renderDirectory() {
  const ranked = getFilteredAndRankedHospitals();
  renderKpiStrip(ranked);

  const totalPages = Math.max(1, Math.ceil(ranked.length / PAGE_SIZE));
  if (state.currentPage > totalPages) state.currentPage = totalPages;
  if (state.currentPage < 1) state.currentPage = 1;

  const startIdx = (state.currentPage - 1) * PAGE_SIZE;
  const pageItems = ranked.slice(startIdx, startIdx + PAGE_SIZE);

  $('#resultsHeading').textContent = `Nearest Hospitals Ranked by Haversine Distance (${ranked.length} found)`;
  $('#coordsReadout').textContent = `Origin: ${state.locationName} (${state.userLat.toFixed(4)}° N, ${state.userLon.toFixed(4)}° E) · Traffic: ${state.trafficLevel.toUpperCase()}`;

  $('#paginationControls').innerHTML = ranked.length > PAGE_SIZE ? `
    <span class="muted-text">Page ${state.currentPage} of ${totalPages}</span>
    <button class="btn btn-secondary" id="prevPageBtn" ${state.currentPage <= 1 ? 'disabled' : ''}>← Prev</button>
    <button class="btn btn-secondary" id="nextPageBtn" ${state.currentPage >= totalPages ? 'disabled' : ''}>Next →</button>
  ` : '';

  if ($('#prevPageBtn')) {
    $('#prevPageBtn').onclick = () => {
      state.currentPage--;
      renderDirectory();
    };
  }
  if ($('#nextPageBtn')) {
    $('#nextPageBtn').onclick = () => {
      state.currentPage++;
      renderDirectory();
    };
  }

  if (!pageItems.length) {
    $('#hospitalGrid').innerHTML = `
      <div class="panel-card" style="grid-column:1/-1;text-align:center;padding:36px">
        <h3>No matching hospitals within current filters</h3>
        <p class="muted-text">Try expanding your distance radius or clearing specialty filter pills.</p>
      </div>
    `;
    return;
  }

  $('#hospitalGrid').innerHTML = pageItems.map(h => {
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${state.userLat},${state.userLon}&destination=${h.lat},${h.lon}&travelmode=driving`;
    return `
      <article class="hospital-card status-${h.status.code}">
        <div class="card-top">
          <div>
            <h3 class="hospital-name">${sanitizeHTML(h.name)}</h3>
            <div class="hospital-meta">${sanitizeHTML(h.address)} · ${sanitizeHTML(h.district)}</div>
          </div>
          <span class="status-badge ${h.status.code}">${sanitizeHTML(h.status.label)}</span>
        </div>

        <div class="proximity-strip">
          <span>📍 ${h.distanceKm.toFixed(2)} km away</span>
          <span>🚑 Golden Hour ETA: ~${h.transit.minutes} mins (${h.transit.goldenHourRisk})</span>
          <span class="freshness-badge ${h.freshness.isStale ? 'stale' : ''}">${sanitizeHTML(h.freshness.text)}</span>
        </div>

        <div class="bed-counters">
          <div class="bed-box ${h.beds.icu === 0 ? 'zero' : 'available'}">
            <strong>${h.beds.icu}</strong>
            <span>ICU</span>
          </div>
          <div class="bed-box ${h.beds.ventilator === 0 ? 'zero' : 'available'}">
            <strong>${h.beds.ventilator}</strong>
            <span>Ventilator</span>
          </div>
          <div class="bed-box ${h.beds.oxygen === 0 ? 'zero' : ''}">
            <strong>${h.beds.oxygen}</strong>
            <span>Oxygen</span>
          </div>
          <div class="bed-box">
            <strong>${h.beds.general}</strong>
            <span>General</span>
          </div>
        </div>

        <div class="tag-row">
          ${h.specialties.map(spec => `<span class="facility-tag">${sanitizeHTML(spec)}</span>`).join('')}
        </div>

        <div class="card-actions">
          <a class="btn btn-danger" href="tel:${sanitizeHTML(h.phone)}">☎ Call ER</a>
          <a class="btn btn-primary" href="${mapsUrl}" target="_blank" rel="noopener noreferrer">🧭 Navigate</a>
          <button class="btn btn-secondary" data-dispatch-id="${sanitizeHTML(h.id)}">🚨 Pre-Alert</button>
        </div>
      </article>
    `;
  }).join('');

  $$('[data-dispatch-id]').forEach(btn => {
    btn.onclick = () => openPreArrivalModal(btn.dataset.dispatchId);
  });
}

function renderLeafletMap() {
  const mapEl = $('#leafletMap');
  if (!mapEl) return;

  if (typeof window.L === 'undefined') {
    mapEl.innerHTML = `<div style="padding:24px">Leaflet map library unavailable offline. Use the Hospital Directory tab for Haversine distances and direct navigation links.</div>`;
    return;
  }

  if (!leafletMap) {
    leafletMap = window.L.map('leafletMap').setView([state.userLat, state.userLon], 12);
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(leafletMap);
    markerLayer = window.L.layerGroup().addTo(leafletMap);
  }

  markerLayer.clearLayers();

  // User origin pin
  window.L.circleMarker([state.userLat, state.userLon], {
    radius: 9,
    color: '#0f766e',
    fillColor: '#14b8a6',
    fillOpacity: 0.95
  })
    .bindPopup(`<b>Your Location</b><br>${sanitizeHTML(state.locationName)}`)
    .addTo(markerLayer);

  const ranked = getFilteredAndRankedHospitals();
  ranked.forEach(h => {
    const pinColor = h.status.code === 'divert' ? '#dc2626' : h.status.code === 'busy' ? '#d97706' : '#16a34a';
    window.L.circleMarker([h.lat, h.lon], {
      radius: 10,
      color: '#ffffff',
      weight: 2,
      fillColor: pinColor,
      fillOpacity: 0.95
    })
      .bindPopup(`
        <b>${sanitizeHTML(h.name)}</b><br>
        Status: <b>${sanitizeHTML(h.status.label)}</b><br>
        Distance: ${h.distanceKm.toFixed(2)} km (~${h.transit.minutes} mins)<br>
        ICU: ${h.beds.icu} · Vent: ${h.beds.ventilator} · O₂: ${h.beds.oxygen}<br>
        <a href="tel:${sanitizeHTML(h.phone)}">Call ${sanitizeHTML(h.phone)}</a>
      `)
      .addTo(markerLayer);
  });

  setTimeout(() => leafletMap.invalidateSize(), 120);
}

function renderAdminConsole() {
  const root = $('#adminConsoleRoot');
  if (!state.adminSession) {
    root.innerHTML = `
      <div class="panel-card" style="max-width:520px;margin:12px auto">
        <h2>🔒 Protected Hospital Bed Update Console</h2>
        <p class="muted-text">
          Authorized ER desk coordinators must authenticate before incrementing or decrementing live bed counts.
        </p>
        <div class="control-group" style="margin-top:16px">
          <label for="adminStaffId">HOSPITAL STAFF ID</label>
          <input id="adminStaffId" class="form-control" value="MED-ADMIN" placeholder="e.g. MED-ADMIN">
        </div>
        <div class="control-group" style="margin-top:12px">
          <label for="adminPin">EMERGENCY ACCESS PIN</label>
          <input id="adminPin" type="password" class="form-control" value="1080" placeholder="Enter 4-digit PIN">
        </div>
        <p class="muted-text" style="margin-top:10px;font-size:12px">
          Demo Staff Credentials: <b>MED-ADMIN</b> / PIN: <b>1080</b>
        </p>
        <button class="btn btn-primary" id="adminLoginBtn" style="margin-top:14px;width:100%">
          Authenticate &amp; Unlock Console
        </button>
      </div>
    `;

    $('#adminLoginBtn').onclick = async () => {
      const staffId = $('#adminStaffId').value;
      const pin = $('#adminPin').value;
      const res = await loginHospitalAdmin({ staffId, pin });
      if (!res.ok) {
        notify(res.error || 'Authentication failed.');
        return;
      }
      state.adminSession = { token: res.token, staff: res.staff };
      notify(`Authenticated as ${res.staff.staffId}`);
      renderAdminConsole();
    };
    return;
  }

  root.innerHTML = `
    <div class="panel-card">
      <div class="section-header">
        <div>
          <h2>🏥 Live Hospital Bed Inventory Console</h2>
          <p class="muted-text">
            Signed in as <b>${sanitizeHTML(state.adminSession.staff.staffId)}</b> · Changes sync immediately with the directory and map.
          </p>
        </div>
        <button class="btn btn-outline" id="adminLogoutBtn">Sign Out</button>
      </div>

      <div style="overflow-x:auto">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Hospital</th>
              <th>Status</th>
              <th>ICU Beds</th>
              <th>Ventilators</th>
              <th>Oxygen</th>
              <th>General</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${state.hospitals.map(h => {
              const st = getEmergencyStatus(h.beds);
              return `
                <tr data-admin-row="${sanitizeHTML(h.id)}">
                  <td>
                    <b>${sanitizeHTML(h.name)}</b><br>
                    <span class="muted-text" style="font-size:12px">${sanitizeHTML(h.district)}</span>
                  </td>
                  <td><span class="status-badge ${st.code}">${sanitizeHTML(st.label)}</span></td>
                  <td><input type="number" min="0" max="500" class="form-control" style="width:76px" data-bed="icu" value="${h.beds.icu}"></td>
                  <td><input type="number" min="0" max="500" class="form-control" style="width:76px" data-bed="ventilator" value="${h.beds.ventilator}"></td>
                  <td><input type="number" min="0" max="500" class="form-control" style="width:76px" data-bed="oxygen" value="${h.beds.oxygen}"></td>
                  <td><input type="number" min="0" max="500" class="form-control" style="width:82px" data-bed="general" value="${h.beds.general}"></td>
                  <td><button class="btn btn-primary" data-save-hosp="${sanitizeHTML(h.id)}">Save Live</button></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  $('#adminLogoutBtn').onclick = () => {
    logoutHospitalAdmin();
    state.adminSession = null;
    notify('Signed out of Hospital Admin Console.');
    renderAdminConsole();
  };

  $$('[data-save-hosp]').forEach(btn => {
    btn.onclick = async () => {
      const hospId = btn.dataset.saveHosp;
      const row = $(`[data-admin-row="${hospId}"]`);
      if (!row) return;

      const icuCheck = validateBedCount(row.querySelector('[data-bed="icu"]').value);
      const ventCheck = validateBedCount(row.querySelector('[data-bed="ventilator"]').value);
      const oxyCheck = validateBedCount(row.querySelector('[data-bed="oxygen"]').value);
      const genCheck = validateBedCount(row.querySelector('[data-bed="general"]').value);

      if (!icuCheck.valid || !ventCheck.valid || !oxyCheck.valid || !genCheck.valid) {
        notify('All bed counts must be valid integers between 0 and 500.');
        return;
      }

      const nextBeds = {
        icu: icuCheck.value,
        ventilator: ventCheck.value,
        oxygen: oxyCheck.value,
        general: genCheck.value
      };

      const apiRes = await updateHospitalBedsProtected(hospId, nextBeds, state.adminSession.token);
      if (!apiRes.ok) {
        notify(apiRes.error || 'Failed to update bed counts.');
        return;
      }

      const target = state.hospitals.find(h => h.id === hospId);
      if (target) {
        target.beds = nextBeds;
        target.updatedAt = new Date().toISOString();
      }
      writeCachedHospitals(state.hospitals);
      renderAdminConsole();
      renderDirectory();
      notify(`Updated live beds for ${target?.name || hospId}`);
    };
  });
}

function openPreArrivalModal(hospitalId) {
  const hospital = state.hospitals.find(h => h.id === hospitalId);
  if (!hospital) return;
  const distanceKm = calculateHaversineKm(state.userLat, state.userLon, hospital.lat, hospital.lon);
  const transit = estimateGoldenHourTransit(distanceKm, state.trafficLevel);

  $('#modalRoot').innerHTML = `
    <div class="modal-backdrop" id="dispatchBackdrop">
      <div class="modal-card" role="dialog" aria-modal="true">
        <h3>🚨 Ambulance Pre-Arrival Dispatch Alert</h3>
        <p class="muted-text">Receiving ER: <b>${sanitizeHTML(hospital.name)}</b> (ETA ~${transit.minutes} mins)</p>
        <div class="control-group" style="margin-top:12px">
          <label for="dispatchType">CRITICAL CONDITION</label>
          <select id="dispatchType" class="form-control">
            <option value="Cardiac Arrest / STEMI">Cardiac Arrest / STEMI</option>
            <option value="Severe Polytrauma / RTA">Severe Polytrauma / Road Accident</option>
            <option value="Acute Ischemic Stroke">Acute Ischemic Stroke</option>
            <option value="Respiratory Distress / Ventilator Needed">Respiratory Distress / Ventilator Needed</option>
            <option value="Pediatric Emergency">Pediatric Emergency</option>
          </select>
        </div>
        <div class="control-group" style="margin-top:12px">
          <label for="dispatchNotes">PARAMEDIC TRIAGE NOTES</label>
          <input id="dispatchNotes" class="form-control" maxlength="200" placeholder="e.g. Male 54y, SpO2 88%, O2 support active">
        </div>
        <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px">
          <button class="btn btn-outline" id="closeDispatchModal">Cancel</button>
          <button class="btn btn-danger" id="submitDispatchBtn">Transmit ER Alert</button>
        </div>
      </div>
    </div>
  `;

  const close = () => {
    $('#modalRoot').innerHTML = '';
  };
  $('#closeDispatchModal').onclick = close;
  $('#dispatchBackdrop').onclick = e => {
    if (e.target.id === 'dispatchBackdrop') close();
  };

  $('#submitDispatchBtn').onclick = async () => {
    const notesCheck = sanitizeSearchOrText($('#dispatchNotes').value, { maxLen: 200, field: 'Notes' });
    const res = await sendPreArrivalDispatch({
      hospitalId: hospital.id,
      hospitalName: hospital.name,
      emergencyType: $('#dispatchType').value,
      etaMinutes: transit.minutes,
      notes: notesCheck.value
    });
    if (res.ok && res.dispatch) {
      state.dispatches.unshift(res.dispatch);
      updateDispatchBadge();
      close();
      notify(`Pre-Arrival Alert ${res.dispatch.id} transmitted to ${hospital.name}`);
    }
  };
}

function updateDispatchBadge() {
  const badge = $('#dispatchCount');
  if (badge) badge.textContent = String(state.dispatches.length);
}

function renderDispatchLog() {
  updateDispatchBadge();
  const root = $('#dispatchRoot');
  root.innerHTML = `
    <div class="panel-card">
      <h2>🚑 Ambulance Pre-Arrival Dispatch Log</h2>
      <p class="muted-text">Real-time digital alerts transmitted to receiving hospital emergency desks prior to ambulance arrival.</p>
      ${state.dispatches.length ? `
        <div style="display:grid;gap:10px;margin-top:16px">
          ${state.dispatches.map(d => `
            <div style="border:1px solid var(--border);border-radius:10px;padding:12px 16px;background:var(--surface-alt)">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <strong>${sanitizeHTML(d.id)} · ${sanitizeHTML(d.hospitalName)}</strong>
                <span class="status-badge normal">${sanitizeHTML(d.status)} · ETA ${d.etaMinutes}m</span>
              </div>
              <div style="margin-top:4px;font-size:13px"><b>Condition:</b> ${sanitizeHTML(d.emergencyType)} ${d.notes ? `— ${sanitizeHTML(d.notes)}` : ''}</div>
            </div>
          `).join('')}
        </div>
      ` : '<p class="muted-text" style="margin-top:16px">No pre-arrival alerts sent yet. Click <b>🚨 Pre-Alert</b> on any hospital card to notify its ER desk.</p>'}
    </div>
  `;
}

function switchTab(tabName) {
  state.activeTab = tabName;
  $$('.nav-tab').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tabName));
  $$('.view-panel').forEach(panel => panel.classList.toggle('active', panel.id === `view-${tabName}`));

  if (tabName === 'directory') renderDirectory();
  if (tabName === 'map') renderLeafletMap();
  if (tabName === 'admin') renderAdminConsole();
  if (tabName === 'dispatch') renderDispatchLog();
}

function initControls() {
  // Location Presets
  $('#locationPreset').innerHTML = CITY_PRESETS.map(p =>
    `<option value="${p.id}">${sanitizeHTML(p.name)}</option>`
  ).join('');

  $('#locationPreset').onchange = e => {
    const preset = CITY_PRESETS.find(p => p.id === e.target.value);
    if (preset) {
      state.userLat = preset.lat;
      state.userLon = preset.lon;
      state.locationName = preset.name;
      state.currentPage = 1;
      renderDirectory();
      if (state.activeTab === 'map') renderLeafletMap();
    }
  };

  $('#useLiveGps').onclick = () => {
    if (!('geolocation' in navigator)) {
      notify('Geolocation not supported in this browser; using selected district.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        state.userLat = Number(pos.coords.latitude.toFixed(4));
        state.userLon = Number(pos.coords.longitude.toFixed(4));
        state.locationName = 'Live Device GPS';
        state.currentPage = 1;
        renderDirectory();
        if (state.activeTab === 'map') renderLeafletMap();
        notify('Updated origin to live device GPS coordinates.');
      },
      () => {
        notify('GPS permission denied or unavailable — using simulated city district.');
      },
      { timeout: 5000 }
    );
  };

  $('#searchInput').oninput = e => {
    state.searchQuery = e.target.value;
    state.currentPage = 1;
    renderDirectory();
  };

  $('#bedRequirement').onchange = e => {
    state.bedRequirement = e.target.value;
    state.currentPage = 1;
    renderDirectory();
  };

  $('#radiusFilter').onchange = e => {
    state.maxKm = Number(e.target.value) || 0;
    state.currentPage = 1;
    renderDirectory();
  };

  $('#trafficLevel').onchange = e => {
    state.trafficLevel = e.target.value;
    renderDirectory();
  };

  // Specialty Pills
  $('#specialtyPills').innerHTML = ALL_SPECIALTIES.map(spec =>
    `<button type="button" class="spec-pill" data-spec="${sanitizeHTML(spec)}">${sanitizeHTML(spec)}</button>`
  ).join('');

  $$('.spec-pill').forEach(pill => {
    pill.onclick = () => {
      const spec = pill.dataset.spec;
      if (state.selectedSpecialties.has(spec)) {
        state.selectedSpecialties.delete(spec);
        pill.classList.remove('active');
      } else {
        state.selectedSpecialties.add(spec);
        pill.classList.add('active');
      }
      state.currentPage = 1;
      renderDirectory();
    };
  });

  $('#resetFilters').onclick = () => {
    state.searchQuery = '';
    state.bedRequirement = 'any';
    state.maxKm = 0;
    state.selectedSpecialties.clear();
    state.currentPage = 1;
    $('#searchInput').value = '';
    $('#bedRequirement').value = 'any';
    $('#radiusFilter').value = '0';
    $$('.spec-pill').forEach(p => p.classList.remove('active'));
    renderDirectory();
  };

  $$('.nav-tab').forEach(tab => {
    tab.onclick = () => switchTab(tab.dataset.tab);
  });

  $('#themeToggle').onclick = () => {
    document.body.classList.toggle('theme-dark');
  };

  $('#recenterMap').onclick = () => {
    if (leafletMap) leafletMap.setView([state.userLat, state.userLon], 13);
  };
}

// Register Offline Service Worker when hosted over HTTP/HTTPS
if ('serviceWorker' in navigator && window.location.protocol !== 'file:') {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

// Hydrate live hospital inventory from 3-tier backend API if available
fetchHospitalsFromApi({ lat: state.userLat, lon: state.userLon }).then(apiHospitals => {
  if (apiHospitals && apiHospitals.length) {
    state.hospitals = apiHospitals;
    writeCachedHospitals(apiHospitals);
    renderDirectory();
  }
});

initControls();
updateDispatchBadge();
renderDirectory();
