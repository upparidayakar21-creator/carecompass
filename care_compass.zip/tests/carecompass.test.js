/**
 * @fileoverview Automated Unit & Integration Test Suite for CareCompass: BedFinder Blitz v2.0
 * Run via: npm test  (or node --test tests/carecompass.test.js)
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  calculateHaversineKm,
  estimateGoldenHourTransit,
  getEmergencyStatus,
  getFreshnessInfo
} from '../js/haversine.js';

import {
  sanitizeHTML,
  sanitizeSearchOrText,
  validateBedCount
} from '../js/security.js';

import { INITIAL_HOSPITALS } from '../js/hospitals-data.js';
import { server } from '../server.js';

test('Haversine Distance: returns 0 km for identical coordinates and accurate geodesic distance', () => {
  assert.equal(calculateHaversineKm(17.4399, 78.4983, 17.4399, 78.4983), 0);
  const km = calculateHaversineKm(17.4399, 78.4983, 17.4485, 78.5012);
  assert.ok(km > 0.9 && km < 1.2, `Expected ~1.0 km, got ${km}`);
});

test('Haversine Distance: throws TypeError on non-numeric coordinates', () => {
  assert.throws(() => calculateHaversineKm('bad', 78.4, 17.5, 78.5), TypeError);
});

test('Golden Hour Transit Estimator: scales ETA with traffic congestion', () => {
  const low = estimateGoldenHourTransit(10, 'low');
  const heavy = estimateGoldenHourTransit(10, 'heavy');
  assert.ok(heavy.minutes > low.minutes);
  assert.equal(low.goldenHourRisk, 'Optimal');
});

test('Emergency Status Classifier: classifies Normal, Busy, and Divert accurately', () => {
  assert.equal(getEmergencyStatus({ general: 40, icu: 6, ventilator: 4, oxygen: 20 }).code, 'normal');
  assert.equal(getEmergencyStatus({ general: 30, icu: 2, ventilator: 1, oxygen: 10 }).code, 'busy');
  assert.equal(getEmergencyStatus({ general: 50, icu: 0, ventilator: 0, oxygen: 8 }).code, 'divert');
});

test('Freshness & Staleness Detector: flags records >= 240 mins (4 hours) old', () => {
  const now = Date.now();
  const fresh = getFreshnessInfo(new Date(now - 10 * 60000).toISOString(), now);
  const stale = getFreshnessInfo(new Date(now - 260 * 60000).toISOString(), now);
  assert.equal(fresh.isStale, false);
  assert.equal(stale.isStale, true);
});

test('XSS Sanitization & Bed Count Validation: escapes script tags and enforces integer bounds', () => {
  const escaped = sanitizeHTML('<script>alert("xss")</script>');
  assert.ok(!escaped.includes('<script>'));

  const cleanQuery = sanitizeSearchOrText('  <img src=x>City Care  ');
  assert.equal(cleanQuery.value, 'img src=xCity Care');

  assert.equal(validateBedCount(12).valid, true);
  assert.equal(validateBedCount(-1).valid, false);
  assert.equal(validateBedCount(3.5).valid, false);
});

test('Dataset Integrity: 15 urban district hospitals seeded with coordinates and specialties', () => {
  assert.equal(INITIAL_HOSPITALS.length, 15);
  for (const h of INITIAL_HOSPITALS) {
    assert.ok(Number.isFinite(h.lat) && Number.isFinite(h.lon));
    assert.ok(Array.isArray(h.specialties) && h.specialties.length >= 1);
  }
});

test('3-Tier Backend REST API: rejects unauthenticated bed updates (401) and persists authenticated PATCH (200)', async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  try {
    // 1. Proximity search endpoint
    const listRes = await fetch(`${baseUrl}/api/hospitals?lat=17.4399&lon=78.4983&maxKm=10`);
    assert.equal(listRes.status, 200);
    const listData = await listRes.json();
    assert.ok(listData.count > 0);
    assert.ok(listData.hospitals[0].distanceKm <= listData.hospitals[listData.hospitals.length - 1].distanceKm);

    // 2. Unauthenticated bed update must fail with 401
    const unauthPatch = await fetch(`${baseUrl}/api/hospitals/hosp-01/beds`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ beds: { general: 40, icu: 0, ventilator: 0, oxygen: 10 } })
    });
    assert.equal(unauthPatch.status, 401);

    // 3. Authenticate with valid staff credentials
    const loginRes = await fetch(`${baseUrl}/api/auth/admin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ staffId: 'MED-ADMIN', pin: '1080' })
    });
    assert.equal(loginRes.status, 200);
    const { token } = await loginRes.json();
    assert.ok(token);

    // 4. Authenticated bed update succeeds and updates status to Divert when ICU = 0
    const authPatch = await fetch(`${baseUrl}/api/hospitals/hosp-01/beds`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ beds: { general: 40, icu: 0, ventilator: 0, oxygen: 10 } })
    });
    assert.equal(authPatch.status, 200);
    const updated = await authPatch.json();
    assert.equal(updated.status.code, 'divert');

    // 5. Ambulance Pre-Arrival Dispatch endpoint
    const dispRes = await fetch(`${baseUrl}/api/dispatch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hospitalId: 'hosp-02',
        hospitalName: 'Apex Heart & Trauma Institute',
        emergencyType: 'Cardiac Arrest / STEMI',
        etaMinutes: 9,
        notes: 'STEMI protocol activated'
      })
    });
    assert.equal(dispRes.status, 201);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});
