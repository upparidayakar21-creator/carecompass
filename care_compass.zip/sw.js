/**
 * @fileoverview Offline Hospital Directory Service Worker for CareCompass
 * Caches core app shell and essential hospital emergency hotlines/addresses for offline access.
 */

const CACHE_NAME = 'carecompass-offline-v2';
const CORE_ASSETS = [
  './',
  './index.html',
  './styles.css',
  './js/app.js',
  './js/haversine.js',
  './js/hospitals-data.js',
  './js/security.js',
  './js/storage.js'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone)).catch(() => {});
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
