# CareCompass: BedFinder Blitz (v2.0 — 3-Tier Architecture)

A real-time hospital bed availability tracker, Haversine geodesic proximity router, interactive Leaflet map, protected hospital admin console, and ambulance pre-arrival dispatch system.

## Quick Start

### 1. Run the 3-Tier Server (`Node.js` REST API + JSON Database + Frontend)
```bash
npm start
```
Open **`http://localhost:3000`** in Chrome or Edge.

### 2. Run Automated Unit & Integration Tests
```bash
npm test
```
Or open **`test.html`** in a browser to run the client-side test suite.

## Protected Hospital Admin Console Credentials
- **Staff ID:** `MED-ADMIN`
- **Emergency PIN:** `1080`
*(Unauthenticated `PATCH /api/hospitals/:id/beds` requests are rejected with `401 Unauthorized`.)*

## Directory Structure
- `index.html` — Semantic HTML5 emergency triage dashboard, directory, Leaflet map, admin console, and dispatch log.
- `styles.css` — High-contrast accessible CSS3 Grid/Flexbox stylesheet with dark mode.
- `js/haversine.js` — Geodesic Haversine formula, Golden Hour ETA estimator, emergency status classifier, and 4-hour staleness detector.
- `js/hospitals-data.js` — Comprehensive 15-hospital urban district dataset.
- `js/security.js` — XSS HTML escaping, search input sanitization, and integer bed count validation.
- `js/storage.js` — 3-tier REST API client, Bearer token session management, and quota-safe `localStorage` fallback.
- `js/app.js` — Modular SPA controller with pagination (`6 hospitals/page`), Leaflet map pins, and pre-arrival dispatch modal.
- `server.js` — Zero-dependency Node.js REST API (`GET /api/hospitals`, `POST /api/auth/admin`, `PATCH /api/hospitals/:id/beds`, `POST /api/dispatch`) with JSON persistence (`data/carecompass-db.json`).
- `sw.js` — Service Worker caching essential hospital hotlines and addresses for offline use.
- `tests/carecompass.test.js` & `test.html` — Automated unit and API integration test suites.
