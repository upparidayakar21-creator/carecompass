CareCompass - BedFinder Blitz

How to run:
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open index.html with Live Server, or double-click index.html to open it in a browser.
4. An internet connection is needed for the Leaflet map and map tiles.

Note:
The hospital names, phone numbers, coordinates and bed counts in this project are sample/demo data.
The Admin Console is a front-end demonstration; edits are not saved permanently after a page refresh.
For actual emergencies in India, call 112 and confirm availability directly with hospitals.
